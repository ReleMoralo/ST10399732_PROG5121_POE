package RegistrationLogin;

import javax.swing.JOptionPane;

class Login {

    public boolean checkUsername() {
        return Registration.username.contains("_") && Registration.username.length() <= 5;
    }

    public boolean checkPasswordComplexity() {
        boolean passwordValid = false;
        boolean hasLength = false;
        boolean hasNumber = false;
        boolean hasSpecialChar = false;
        boolean hasUpperCase = false;
        char ch;

        if (Registration.password.length() >= 8) {
            hasLength = true;
        }
        for (int i = 0; i < Registration.password.length(); i++) {
            ch = Registration.password.charAt(i);

            if (Character.isDigit(ch)) {
                hasNumber = true;
            }
            if (Character.isUpperCase(ch)) {
                hasUpperCase = true;
            }
            if (!Character.isLetterOrDigit(ch)) {
                hasSpecialChar = true;
            }

            passwordValid = hasSpecialChar && hasNumber && hasLength && hasUpperCase;
        }
        return passwordValid;
    }

    public void registerUser() {
        if (checkUsername()) {
            JOptionPane.showMessageDialog(null, "USER REGISTRATION\nUsername successfully captured");
        } else {
            JOptionPane.showMessageDialog(null, "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.");
        }
        if (checkPasswordComplexity()) {
            JOptionPane.showMessageDialog(null, "USER REGISTRATION\nPassword successfully captured");
        } else {
            JOptionPane.showMessageDialog(null, "Password is not correctly formatted, please ensure the password contains at least 8 characters, a capital letter, a number, and a special character.");
        }
    }

    public boolean loginUser() {
        String enteredUsername = JOptionPane.showInputDialog("USER LOGIN\nEnter Username:");
        String enteredPassword = JOptionPane.showInputDialog("USER LOGIN\nEnter Password:");

        return Registration.username.equals(enteredUsername) && Registration.password.equals(enteredPassword);
    }

    public String returnLoginStatus() {
        if (loginUser()) {
            return "Thank you\n" + Registration.firstName + " " + Registration.surname + "\nYou have successfully logged in.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}
