package RegistrationLogin;

import javax.swing.JOptionPane;

public class Task {
    UserInfo userInfo = new UserInfo();

    public boolean checkTaskDescription() {
        return userInfo.getDescription().length() <= 50;
    }

    public static String createTaskID() {
        String developerInitials = "";
        String developerNames = UserInfo.getDeveloperNames();

        for (int i = 0; i < developerNames.length(); i++) {
            char ch = developerNames.charAt(i);
            if (ch == ' ') {
                developerInitials = developerNames.substring(i - 3, i);
                break;
            }
        }

        String taskID = UserInfo.getTaskName().substring(0, 2) + ":"
                + UserInfo.getTaskNumber() + ":"
                + developerInitials;

        return taskID.toUpperCase();
    }

    public static String printTaskDetails() {
        return UserInfo.getStatus() + "\n"
                + UserInfo.getDeveloperNames() + "\n"
                + UserInfo.getTaskNumber() + "\n"
                + UserInfo.getTaskName() + "\n"
                + UserInfo.getDescription() + "\n"
                + createTaskID() + "\n"
                + UserInfo.getDuration();
    }

    public int returnTotalHours() {
        return UserInfo.getDuration();
    }
}
