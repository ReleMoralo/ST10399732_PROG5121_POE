package RegistrationLogin;

import javax.swing.JOptionPane;

public class Registration {

    static String firstName;
    static String username;
    static String surname;
    static String password;

    public static void collectUserDetails() {
        firstName = JOptionPane.showInputDialog("Please enter your first name:");
        surname = JOptionPane.showInputDialog("Please enter your surname:");
        username = JOptionPane.showInputDialog("Please enter your username:");
        password = JOptionPane.showInputDialog("Please enter your password:");
    }

    public static void main(String[] args) {
        collectUserDetails();
        Login loginObject = new Login();

        loginObject.checkUsername();
        loginObject.registerUser();

        UserInfo userInfo = new UserInfo();
        userInfo.displayWelcomeNote();
    }
}
