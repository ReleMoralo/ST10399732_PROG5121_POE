package RegistrationLogin;

import javax.swing.JOptionPane;

class UserInfo {
    private static int numberOfTasks;
    private static String taskName;
    private static int taskNumber;
    private static String description;
    private static String developerNames;
    private static int duration;
    private static String status;
    static int totalDuration = 0;

    public static void setNumberOfTasks() {
        numberOfTasks = Integer.parseInt(JOptionPane.showInputDialog("Enter number of tasks you wish to perform:"));
    }

    public static int getNumberOfTasks() {
        return numberOfTasks;
    }

    public static void setTaskName() {
        taskName = JOptionPane.showInputDialog("Enter Task Name:");
    }

    public static String getTaskName() {
        return taskName;
    }

    public static void setTaskNumber(int number) {
        taskNumber = number;
    }

    public static int getTaskNumber() {
        return taskNumber;
    }

    public static void setDescription() {
        description = JOptionPane.showInputDialog("Enter Task Description:");
    }

    public static String getDescription() {
        return description;
    }

    public static void setDeveloperNames() {
        developerNames = JOptionPane.showInputDialog("Enter Developer Names:");
    }

    public static String getDeveloperNames() {
        return developerNames;
    }

    public static void setDuration() {
        duration = Integer.parseInt(JOptionPane.showInputDialog("Enter Task Duration (in hours):"));
    }

    public static int getDuration() {
        return duration;
    }

    public static void setStatus() {
        status = JOptionPane.showInputDialog("Choose Task Status:\nTo Do\nDoing\nDone");
    }

    public static String getStatus() {
        return status;
    }

    public static void displayWelcomeNote() {
        int option;
        int end = 0;
        Login login = new Login();
        Task task = new Task();

        if (login.loginUser()) {
            do {
                option = Integer.parseInt(JOptionPane.showInputDialog("Welcome to EasyKanban\n"
                        + "Please select an option:\n"
                        + "1. Add Task\n"
                        + "2. Show Report\n"
                        + "3. Quit"));

                if (option == 1) {
                    setNumberOfTasks();

                    for (int count = 0; count < getNumberOfTasks(); count++) {
                        setStatus();
                        setTaskNumber(count);
                        setTaskName();
                        setDescription();
                        setDuration();
                        setDeveloperNames();

                        totalDuration += getDuration();
                        JOptionPane.showMessageDialog(null, task.printTaskDetails());
                    }

                    JOptionPane.showMessageDialog(null, "These tasks will take " + totalDuration + " hours to implement.");
                    continue;
                } else if (option == 2) {
                    JOptionPane.showMessageDialog(null, "Coming soon");
                    continue;
                } else if (option == 3) {
                    end = 3;
                }
            } while (end != 3);
        }
    }
}
