/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poepart1;
import java.util.Scanner;
/**
 *
 * @author Rc_student
 */
public class LOGIN {
    
    
    String passwordMessage;
    
    String usernameMessage;
   
    /*Check to see if the username contains an underscore and is not longer than 5 letters*/
    public boolean checkUserName(String userName){
        return userName.contains("_") && userName.length() <= 5;
    }

    /*Check if the password is at least 8 characters long, contains an upercase, a number and a special character*/
    public boolean checkPasswordComplexity(String password){
        
        boolean passwordComplex = false;
        boolean hasNumber = false;
        boolean hasUppercase = false;
        boolean hasSpecialChar = false;
        char current;
        
        // loop executes only if the password meets the length constraint
        if (password.length() >= 8){ 
            for (int i =0; i < password.length(); i++){
                current = password.charAt(i);

                if(Character.isDigit(current)){
                    hasNumber = true;
                }
                else if(Character.isUpperCase(current)){
                    hasUppercase = true;
                }
                else if (!(Character.isLetterOrDigit(current))){
                    hasSpecialChar = true;
                }
            }
        }    
            
        if(hasNumber && hasUppercase && hasSpecialChar){
            passwordComplex = true;
        }
        return passwordComplex;
        
    }

    /*The method takes a password and a username as arguments.
    * It then returns a message that is determined by whether the password and username meet the entry requirements.
    */
    public String registerUser(String pass, String name){
        if (checkPasswordComplexity(pass)){
            passwordMessage = "Password successfully created.";
        }
        else{
            passwordMessage = "Password is not strong enough. Make sure it contains at least 8 characters, "
                    + "including an uppercase letter, a number, and a special character.";
        }
        
        if (checkUserName(name)){
            usernameMessage = "Username successfully created.";
        }
        else{
            usernameMessage = "Username is not valid. Make sure it contains an underscore and is no longer than 5 characters.";
        }
        
        return (usernameMessage+ "\n" + passwordMessage);
    }

    
    public boolean loginUser(boolean checkName, boolean checkPassword, String passwrd, String userName){
        
        boolean logged = false;
        if(checkName && checkPassword) { //only run if the user successfully registered

            Scanner in = new Scanner(System.in);
            System.out.println("");
            System.out.println(" *** LOGIN *** ");            
            System.out.println("Enter your username: ");
            String username = in.nextLine();
            System.out.println("Enter your password: ");
            String password = in.nextLine();
            
            if (password.equals(passwrd) && username.equals(userName)  ){
                logged = true;
            }
        }
        return logged;
    }
    
    
    public String returnLoginStatus(boolean regStatus, String name, String surname){
        String message;
        
        /*
        To avoid unnecessary messages, the login status will only be returned if the user managed to register an account.
        Meaning that an appropriate message will only be displayed depending on wether the login details meet the details
        used to create an account*/
        
        message = "Incorrect username and/or password, Please try again.";
        
        if (regStatus){
            message = "Welcome back, " + name + " " + surname + "!.";
        }
        return message;
    }

    //test data 
    String u_name = "zay_n";
    String pass = "S3cUr3P@ssw0rd";

    
}
